import { CenterFocusStrong } from '@material-ui/icons';
import React from 'react';

const Successfull = () => {
    return(
        <h1 style={{fontSize:'50px', textAlign:'center', color:'green'}}>Great Success</h1>
    )
}

export default Successfull;